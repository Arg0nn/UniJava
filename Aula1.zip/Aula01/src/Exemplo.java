
import javax.swing.JOptionPane;
                          
public class Exemplo {
                              
    public static void main(String[] args) {
      int idade;                                            
      idade = Byte.parseByte(JOptionPane.showInputDialog(null,"Qual sua idade?", "Idade", 3));
      JOptionPane.showMessageDialog(null,"Você tem " + idade + " anos", "Idade", 1);
               
      if (idade >0 & idade< 100) {
        if (idade >= 18) {
          JOptionPane.showMessageDialog(null,"Você é maior de idade", "Idade", 1);
        } else {
          JOptionPane.showMessageDialog(null,"Você é menor de idade", "Idade", 1);
        }
      } else {
        JOptionPane.showMessageDialog(null,"Idade inválida", "Idade", 0);
      }
                       
      JOptionPane.showMessageDialog(null,"Você nasceu em: " + (2020-idade), "Idade", 1);
    }
    
    // Exercício
    
  
}